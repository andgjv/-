package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import com.example.config.FileSwapConfig
import com.example.util.FilePathResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SwapResult(
    val success: Boolean,
    val message: String
)

data class FilePreviewInfo(
    val path: String,
    val exists: Boolean,
    val fileName: String,
    val contentPreview: String,
    val lastModified: String
)

class FileSwapManager(private val context: Context) {

    private val _updateEvents = MutableSharedFlow<Unit>(extraBufferCapacity = 10)
    val updateEvents: SharedFlow<Unit> = _updateEvents.asSharedFlow()

    fun notifyStateChanged() {
        _updateEvents.tryEmit(Unit)
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(
        FileSwapConfig.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun getFileAPath(): String {
        return prefs.getString(FileSwapConfig.KEY_FILE_A, null) ?: getDefaultFileAPath()
    }

    fun getFileBPath(): String {
        return prefs.getString(FileSwapConfig.KEY_FILE_B, null) ?: getDefaultFileBPath()
    }

    fun getSwapMode(): String = prefs.getString(FileSwapConfig.KEY_SWAP_MODE, "TASK1_RENAME_BOTH") ?: "TASK1_RENAME_BOTH"

    fun setSwapMode(mode: String) {
        prefs.edit().putString(FileSwapConfig.KEY_SWAP_MODE, mode).apply()
        notifyStateChanged()
    }

    fun setPaths(pathA: String, pathB: String) {
        prefs.edit().apply {
            putString(FileSwapConfig.KEY_FILE_A, pathA)
            putString(FileSwapConfig.KEY_FILE_B, pathB)
            apply()
        }
        notifyStateChanged()
    }

    fun resetToDefaults() {
        prefs.edit().clear().apply()
        notifyStateChanged()
    }

    private fun getDocumentsDirectory(): File {
        val docsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        if (!docsDir.exists()) {
            docsDir.mkdirs()
        }
        return docsDir
    }

    private fun getDefaultFileAPath(): String {
        val docsDir = getDocumentsDirectory()
        return File(docsDir, "Archive_A.zip").absolutePath
    }

    private fun getDefaultFileBPath(): String {
        val docsDir = getDocumentsDirectory()
        return File(docsDir, "Backup_B.zip").absolutePath
    }

    /**
     * Creates demo files if they don't exist.
     */
    suspend fun createDemoFiles(): SwapResult = withContext(Dispatchers.IO) {
        try {
            val docsDir = getDocumentsDirectory()
            val fileA = File(docsDir, "Archive_A.zip")
            val fileB = File(docsDir, "Backup_B.zip")

            fileA.writeText("محتوى ملف أ (Archive_A.zip)\nتاريخ الإنشاء: ${Date()}")
            fileB.writeText("محتوى ملف ب (Backup_B.zip)\nتاريخ الإنشاء: ${Date()}")

            setPaths(fileA.absolutePath, fileB.absolutePath)
            notifyStateChanged()

            SwapResult(
                success = true,
                message = "تم إنشاء الملفات التجريبية بنجاح! 🎉\nالملف (أ): ${fileA.name}\nالملف (ب): ${fileB.name}"
            )
        } catch (e: Exception) {
            SwapResult(
                success = false,
                message = "حدث خطأ أثناء إنشاء الملفات: ${e.localizedMessage}"
            )
        }
    }

    /**
     * Extracts extension with dot e.g. ".zip" or ""
     */
    private fun getExtensionWithDot(file: File): String {
        val name = file.name
        val lastDot = name.lastIndexOf('.')
        return if (lastDot > 0 && lastDot < name.length - 1) {
            name.substring(lastDot)
        } else {
            ""
        }
    }

    /**
     * Extracts base name without extension
     */
    private fun getBaseNameWithoutExtension(file: File): String {
        val name = file.name
        val lastDot = name.lastIndexOf('.')
        return if (lastDot > 0) {
            name.substring(0, lastDot)
        } else {
            name
        }
    }

    /**
     * Helper to clean input base name (removes matching extension if user typed it)
     */
    private fun cleanBaseName(inputName: String, extensionWithDot: String): String {
        var trimmed = inputName.trim()
        if (extensionWithDot.isNotEmpty() && trimmed.endsWith(extensionWithDot, ignoreCase = true)) {
            trimmed = trimmed.substring(0, trimmed.length - extensionWithDot.length)
        } else {
            val lastDot = trimmed.lastIndexOf('.')
            if (lastDot > 0) {
                trimmed = trimmed.substring(0, lastDot)
            }
        }
        return trimmed.ifBlank { "NewFile_" + (System.currentTimeMillis() % 10000) }
    }

    private fun safeRenameFile(src: File, dst: File): Boolean {
        if (!src.exists()) return false
        try {
            if (src.renameTo(dst)) return true
        } catch (e: Exception) {
            e.printStackTrace()
        }
        // Fallback: copy content then delete original
        try {
            dst.parentFile?.mkdirs()
            src.copyTo(dst, overwrite = true)
            if (dst.exists()) {
                src.delete()
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     * TASK 1: Swapping or renaming file names directly on disk WITHOUT TOUCHING FILE CONTENTS.
     * Preserves file extensions (.zip stays .zip, etc.).
     */
    suspend fun renameFilesDirectly(rawNewNameA: String?, rawNewNameB: String?): SwapResult = withContext(Dispatchers.IO) {
        val pathA = getFileAPath()
        val pathB = getFileBPath()
        val fileA = File(pathA)
        val fileB = File(pathB)

        if (!fileA.exists() || !fileB.exists()) {
            return@withContext SwapResult(
                success = false,
                message = "تعذر الإجراء: تأكد من تحديد ملفين موجودين على القرص! يمكنك الضغط على 'ملفات تجريبية'."
            )
        }

        val baseA = getBaseNameWithoutExtension(fileA)
        val baseB = getBaseNameWithoutExtension(fileB)
        val extA = getExtensionWithDot(fileA)
        val extB = getExtensionWithDot(fileB)

        val parentA = fileA.parentFile ?: getDocumentsDirectory()
        val parentB = fileB.parentFile ?: getDocumentsDirectory()

        // CASE 1: If inputs are empty, SWAP the names of File A and File B
        if (rawNewNameA.isNullOrBlank() && rawNewNameB.isNullOrBlank()) {
            val tempFile = File(parentA, "swap_temp_${System.currentTimeMillis()}.tmp")

            val step1 = safeRenameFile(fileA, tempFile)
            if (!step1) {
                return@withContext SwapResult(success = false, message = "فشل في تبديل أسماء الملفات! تأكد من الأذونات.")
            }

            val targetFileB = File(parentB, "$baseA$extB")
            val targetFileA = File(parentA, "$baseB$extA")

            val step2 = safeRenameFile(fileB, targetFileB)
            val step3 = safeRenameFile(tempFile, targetFileA)

            if (step2 && step3) {
                setPaths(targetFileA.absolutePath, targetFileB.absolutePath)
                notifyStateChanged()
                return@withContext SwapResult(
                    success = true,
                    message = "تم تبديل أسماء الملفين (أ <-> ب) بنجاح! 🔄\n" +
                            "• أصبح الملف (أ): ${targetFileA.name}\n" +
                            "• أصبح الملف (ب): ${targetFileB.name}\n" +
                            "(تم تغيير الأسماء فقط دون المساس بمحتوى أو صيغة أي ملف)."
                )
            } else {
                return@withContext SwapResult(success = false, message = "حدث خطأ أثناء تبديل أسماء الملفات!")
            }
        }

        // CASE 2: Custom renaming for File A or File B
        var newPathA = pathA
        var newPathB = pathB
        var successCount = 0
        val logs = mutableListOf<String>()

        if (!rawNewNameA.isNullOrBlank()) {
            val cleanA = cleanBaseName(rawNewNameA, extA)
            val targetA = File(parentA, "$cleanA$extA")
            if (safeRenameFile(fileA, targetA)) {
                newPathA = targetA.absolutePath
                successCount++
                logs.add("تم تغيير اسم الملف (أ) إلى: ${targetA.name}")
            }
        }

        if (!rawNewNameB.isNullOrBlank()) {
            val cleanB = cleanBaseName(rawNewNameB, extB)
            val targetB = File(parentB, "$cleanB$extB")
            if (safeRenameFile(fileB, targetB)) {
                newPathB = targetB.absolutePath
                successCount++
                logs.add("تم تغيير اسم الملف (ب) إلى: ${targetB.name}")
            }
        }

        if (successCount > 0) {
            setPaths(newPathA, newPathB)
            notifyStateChanged()
            return@withContext SwapResult(
                success = true,
                message = "تمت إعادة التسمية بنجاح! ✨\n" + logs.joinToString("\n") + "\n(دون المساس بمحتوى أو صيغة الملفات)."
            )
        } else {
            return@withContext SwapResult(
                success = false,
                message = "لم يتم تغيير الأسماء! يرجى التأكد من اختيار الأسماء وإتاحة أذونات الوصول."
            )
        }
    }

    /**
     * TASK 2: Copy/Apply Name of File B to File A, and Rename File B with a new custom/generated name.
     * Keeps contents and extensions of both files 100% intact!
     */
    suspend fun copyNameBToAAndRenameB(rawNewNameBForTask2: String?): SwapResult = withContext(Dispatchers.IO) {
        val pathA = getFileAPath()
        val pathB = getFileBPath()
        val fileA = File(pathA)
        val fileB = File(pathB)

        if (!fileA.exists()) {
            return@withContext SwapResult(
                success = false,
                message = "تعذر الإجراء: الملف (أ) غير موجود على القرص!"
            )
        }
        if (!fileB.exists()) {
            return@withContext SwapResult(
                success = false,
                message = "تعذر الإجراء: الملف (ب) غير موجود على القرص!"
            )
        }

        val baseNameB = getBaseNameWithoutExtension(fileB)
        val extA = getExtensionWithDot(fileA)
        val extB = getExtensionWithDot(fileB)

        val timeStamp = SimpleDateFormat("HHmmss", Locale.US).format(Date())
        val defaultBaseNameB = "FileB_New_$timeStamp"
        val cleanNewBaseB = if (!rawNewNameBForTask2.isNullOrBlank()) {
            cleanBaseName(rawNewNameBForTask2, extB)
        } else {
            defaultBaseNameB
        }

        val parentB = fileB.parentFile ?: getDocumentsDirectory()
        val parentA = fileA.parentFile ?: getDocumentsDirectory()

        val targetFileB = File(parentB, "$cleanNewBaseB$extB")
        val targetFileA = File(parentA, "$baseNameB$extA")

        // 1. Rename File B to new target name (frees up original B's name on disk if needed)
        val renamedBSuccess = safeRenameFile(fileB, targetFileB)
        if (!renamedBSuccess) {
            return@withContext SwapResult(
                success = false,
                message = "فشل في إعادة تسمية الملف (ب)! أذونات غير كافية."
            )
        }

        // 2. Rename File A to File B's base name (keeping A's content and extension intact)
        val renamedASuccess = safeRenameFile(fileA, targetFileA)
        if (!renamedASuccess) {
            return@withContext SwapResult(
                success = false,
                message = "تمت إعادة تسمية الملف (ب)، ولكن تعذر تغيير اسم الملف (أ) إلى ${targetFileA.name}!"
            )
        }

        setPaths(targetFileA.absolutePath, targetFileB.absolutePath)
        notifyStateChanged()

        return@withContext SwapResult(
            success = true,
            message = "تمت العملية بنجاح! 🚀\n" +
                    "1️⃣ أصبح اسم الملف (أ): ${targetFileA.name}\n" +
                    "2️⃣ أصبح اسم الملف (ب) الجديد: ${targetFileB.name}\n" +
                    "(مع الحفاظ الكامل 100% على محتوى وصيغة كل ملف دون أي مساس)."
        )
    }

    suspend fun executeMainAction(inputA: String?, inputB: String?): SwapResult = withContext(Dispatchers.IO) {
        val mode = getSwapMode()
        return@withContext when (mode) {
            "TASK1_RENAME_BOTH" -> renameFilesDirectly(inputA, inputB)
            "TASK2_COPY_B_TO_A" -> copyNameBToAAndRenameB(inputB)
            else -> renameFilesDirectly(inputA, inputB)
        }
    }

    suspend fun performSwap(): SwapResult = executeMainAction(null, null)

    fun getFilePreviewInfo(path: String): FilePreviewInfo {
        val file = File(path)
        if (!file.exists()) {
            return FilePreviewInfo(
                path = path,
                exists = false,
                fileName = file.name.ifBlank { "غير مسمى" },
                contentPreview = "الملف غير موجود على القرص.",
                lastModified = "غير متوفر"
            )
        }

        val content = try {
            if (file.length() > 5000) {
                val bytes = ByteArray(300)
                FileInputStream(file).use { it.read(bytes) }
                String(bytes, Charsets.UTF_8).take(200) + "\n... [حجمه ${file.length()} بايت]"
            } else {
                file.readText(Charsets.UTF_8).take(300)
            }
        } catch (e: Exception) {
            "[محتوى ثنائي - حجمه ${file.length()} بايت]"
        }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val modifiedStr = dateFormat.format(Date(file.lastModified()))

        return FilePreviewInfo(
            path = file.absolutePath,
            exists = true,
            fileName = file.name,
            contentPreview = content.ifBlank { "(ملف فارغ)" },
            lastModified = modifiedStr
        )
    }
}

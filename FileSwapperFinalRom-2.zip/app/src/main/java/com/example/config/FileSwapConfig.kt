package com.example.config

/**
 * Global Configuration for File Swapping logic.
 *
 * Customize predefined file paths here or edit them dynamically in the UI settings!
 */
object FileSwapConfig {

    // =========================================================================
    // PREDEFINED DEFAULT FILE PATHS (EDITABLE HERE)
    // =========================================================================
    /** Path to File A */
    const val DEFAULT_FILE_A_PATH = "/sdcard/Documents/FileA.txt"

    /** Path to File B */
    const val DEFAULT_FILE_B_PATH = "/sdcard/Documents/FileB.txt"

    /** Temporary file path used during the three-step swap collision prevention */
    const val DEFAULT_TEMP_PATH = "/sdcard/Documents/FileSwap_temp.tmp"
    // =========================================================================

    const val PREFS_NAME = "file_swapper_prefs"
    const val KEY_FILE_A = "file_a_path"
    const val KEY_FILE_B = "file_b_path"
    const val KEY_TEMP_FILE = "temp_file_path"
    const val KEY_URI_A = "file_a_uri"
    const val KEY_URI_B = "file_b_uri"
    const val KEY_SWAP_MODE = "swap_mode"
    const val KEY_CYCLE_STEP = "cycle_step"
}

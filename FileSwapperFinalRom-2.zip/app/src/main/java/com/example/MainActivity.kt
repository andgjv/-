package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FilePreviewInfo
import com.example.data.FileSwapManager
import com.example.ui.theme.MyApplicationTheme
import com.example.util.FilePathResolver
import com.example.util.PermissionUtils
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var fileSwapManager: FileSwapManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fileSwapManager = FileSwapManager(applicationContext)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen(fileSwapManager = fileSwapManager)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(fileSwapManager: FileSwapManager) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var hasPermission by remember { mutableStateOf(PermissionUtils.hasAllFilesAccess(context)) }

    // Dynamic state
    var swapMode by remember { mutableStateOf(fileSwapManager.getSwapMode()) }
    var inputA by remember { mutableStateOf("") }
    var inputB by remember { mutableStateOf("") }

    var fileAPath by remember { mutableStateOf(fileSwapManager.getFileAPath()) }
    var fileBPath by remember { mutableStateOf(fileSwapManager.getFileBPath()) }

    var infoA by remember { mutableStateOf<FilePreviewInfo?>(null) }
    var infoB by remember { mutableStateOf<FilePreviewInfo?>(null) }

    fun refreshState() {
        hasPermission = PermissionUtils.hasAllFilesAccess(context)
        swapMode = fileSwapManager.getSwapMode()
        fileAPath = fileSwapManager.getFileAPath()
        fileBPath = fileSwapManager.getFileBPath()
        infoA = fileSwapManager.getFilePreviewInfo(fileAPath)
        infoB = fileSwapManager.getFilePreviewInfo(fileBPath)
    }

    LaunchedEffect(Unit) {
        refreshState()
        fileSwapManager.updateEvents.collect {
            refreshState()
        }
    }

    // File selection launchers
    val launcherFileA = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val path = FilePathResolver.getPath(context, uri)
            if (!path.isNullOrBlank()) {
                fileSwapManager.setPaths(path, fileBPath)
                refreshState()
                Toast.makeText(context, "تم تحديد الملف (أ) بنجاح!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val launcherFileB = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val path = FilePathResolver.getPath(context, uri)
            if (!path.isNullOrBlank()) {
                fileSwapManager.setPaths(fileAPath, path)
                refreshState()
                Toast.makeText(context, "تم تحديد الملف (ب) بنجاح!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "مدير أداة إعادة تسمية الملفات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "تبديل أسماء الملفات أو نسخ اسم (ب) إلى (أ) مع الحفاظ على الصيغة والمحتوى",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { refreshState() }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "تحديث")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // PERMISSION ALERT CARD IF NEEDED
            if (!hasPermission) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("permission_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تنبيه: أذونات الملفات مطلوبة!",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Text(
                            text = "لتنفيذ عملية تغيير الأسماء والنسخ على ذاكرة الجهاز الخارجية، يرجى منحي إذن 'وصول لجميع الملفات'.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Button(
                            onClick = {
                                PermissionUtils.requestAllFilesAccess(context)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            )
                        ) {
                            Text("منح الإذن المطلوب الآن")
                        }
                    }
                }
            }

            // ALWAYS-VISIBLE FILE SELECTION CARD (تحديد الملفين أ و ب)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("file_selection_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "📁 تحديد الملفات المستهدفة (أ و ب)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        OutlinedButton(
                            onClick = {
                                coroutineScope.launch {
                                    val res = fileSwapManager.createDemoFiles()
                                    Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                    refreshState()
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ملفات تجريبية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // FILE A SELECTION ROW
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الملف (أ): ${infoA?.fileName ?: "غير مسمى"}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF0284C7),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = fileAPath,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { launcherFileA.launch(arrayOf("*/*")) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                            ) {
                                Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختر (أ)", fontSize = 11.sp)
                            }
                        }
                    }

                    // FILE B SELECTION ROW
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الملف (ب): ${infoB?.fileName ?: "غير مسمى"}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFFD97706),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = fileBPath,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { launcherFileB.launch(arrayOf("*/*")) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
                            ) {
                                Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختر (ب)", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // TASK SELECTION CARD (اختر المهمة المطلوب تنفيذها)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("task_mode_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "⚙️ اختر نوع العملية المطلوب تنفيذها",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    // OPTION 1: SWAP/RENAME FILE NAMES DIRECTLY
                    TaskModeItem(
                        title = "1️⃣ 🔄 تبديل أو تغيير أسماء الملفات (أ <-> ب)",
                        subtitle = "تبديل أسماء الملفات مع بعضها على القرص دون مساس بمحتوى الملف أو صيغته (أو كتابة أسماء مخصصة لهما)",
                        isSelected = swapMode == "TASK1_RENAME_BOTH",
                        onClick = {
                            fileSwapManager.setSwapMode("TASK1_RENAME_BOTH")
                            refreshState()
                        }
                    )

                    // OPTION 2: COPY NAME B TO A AND RENAME B
                    TaskModeItem(
                        title = "2️⃣ 📋 نسخ اسم (ب) إلى (أ) وتسمية (ب) باسم جديد",
                        subtitle = "تسمية الملف (أ) باسم الملف (ب)، وإعطاء (ب) اسماً جديداً مع الحفاظ على محتوى وصيغة كلا الملفين دون أي مساس 100%",
                        isSelected = swapMode == "TASK2_COPY_B_TO_A",
                        onClick = {
                            fileSwapManager.setSwapMode("TASK2_COPY_B_TO_A")
                            refreshState()
                        }
                    )
                }
            }

            // INPUT CONFIGURATION CARD DEPENDING ON SELECTED TASK
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("primary_file_inputs_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (swapMode == "TASK1_RENAME_BOTH") {
                        Text(
                            text = "🔄 معاينة عملية تبديل الأسماء المباشرة (أ <-> ب):",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "• سيصبح اسم الملف (أ) الحالي [${infoA?.fileName ?: "غير مسمى"}] ⬅️ كـ: [${infoB?.fileName ?: "غير مسمى"}]",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0284C7)
                                )
                                Text(
                                    text = "• سيصبح اسم الملف (ب) الحالي [${infoB?.fileName ?: "غير مسمى"}] ⬅️ كـ: [${infoA?.fileName ?: "غير مسمى"}]",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFD97706)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "🔒 تتم هذه العملية مباشرة على القرص دون المساس إطلاقاً بمحتوى أو صيغة أو حجم أي من الملفين.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Optional custom names toggle / inputs if user wants specific names
                        var showCustomInputs by remember { mutableStateOf(false) }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { showCustomInputs = !showCustomInputs }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = if (showCustomInputs) "▼ إخفاء إعادة التسمية بأسماء مخصصة" else "► أو اضغط هنا لكتابة أسماء جديدة مخصصة يدوياً",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }

                        AnimatedVisibility(visible = showCustomInputs) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "اسم مخصص جديد للملف (أ):",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0284C7)
                                    )
                                    OutlinedTextField(
                                        value = inputA,
                                        onValueChange = { inputA = it },
                                        placeholder = { Text("اكتب اسماً جديداً يدوياً للملف أ") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "اسم مخصص جديد للملف (ب):",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD97706)
                                    )
                                    OutlinedTextField(
                                        value = inputB,
                                        onValueChange = { inputB = it },
                                        placeholder = { Text("اكتب اسماً جديداً يدوياً للملف ب") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        // TASK 2: COPY B TO A
                        Text(
                            text = "✍️ إعدادات نسخ اسم (ب) إلى (أ):",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "الاسم الجديد المطلوب للملف (ب) [اتركه فارغاً للتسمية التلقائية]:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            OutlinedTextField(
                                value = inputB,
                                onValueChange = { inputB = it },
                                placeholder = { Text("اتركه فارغاً للتسمية التلقائية بـ FileB_New_... أو اكتب اسماً") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }

            // EXECUTE ACTION BUTTON CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("action_bar_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                val res = fileSwapManager.executeMainAction(inputA, inputB)
                                Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                if (res.success) {
                                    inputA = ""
                                    inputB = ""
                                }
                                refreshState()
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (swapMode == "TASK1_RENAME_BOTH")
                                "تبديل أسماء الملفين (أ <-> ب) دون العبث بالمحتويات 🔄"
                            else
                                "نسخ اسم (ب) إلى (أ) وإعادة تسمية (ب) الآن 🚀",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // THE TWO BOTTOM SQUARE BOXES (الحقلين المربعين في الأسفل للمعاينة والتأكد)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // File A Box
                SquareFilePreviewBox(
                    title = "الملف (أ)",
                    info = infoA,
                    badgeColor = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )

                // File B Box
                SquareFilePreviewBox(
                    title = "الملف (ب)",
                    info = infoB,
                    badgeColor = Color(0xFFD97706),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun TaskModeItem(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        ),
        tonalElevation = if (isSelected) 4.dp else 0.dp
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            RadioButton(
                selected = isSelected,
                onClick = onClick
            )
        }
    }
}

@Composable
fun SquareFilePreviewBox(
    title: String,
    info: FilePreviewInfo?,
    badgeColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.5.dp, badgeColor.copy(alpha = 0.35f)),
        tonalElevation = 3.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header with graphic file interface icon & status dot
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = badgeColor.copy(alpha = 0.15f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                tint = badgeColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = badgeColor
                    )
                }

                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (info?.exists == true) Color(0xFF10B981) else Color(0xFFEF4444))
                )
            }

            // File Name Row with distinct color beside label
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(badgeColor.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "الاسم: ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = info?.fileName ?: "غير مسمى",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = badgeColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Preview Content Box
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = info?.contentPreview ?: "جاري التحميل...",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(8.dp),
                    maxLines = 4,
                    lineHeight = 15.sp
                )
            }

            if (info?.exists == true) {
                Text(
                    text = "التعديل: ${info.lastModified}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}

package com.example.util

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import java.io.File
import java.net.URLDecoder

object FilePathResolver {

    /**
     * Resolves real absolute file path from Uri for external storage on device.
     */
    fun getPath(context: Context, uri: Uri?): String? {
        if (uri == null) return null

        // 1. Direct File Uri
        if ("file".equals(uri.scheme, ignoreCase = true)) {
            val path = uri.path
            if (!path.isNullOrBlank()) {
                return path
            }
        }

        // 2. Try resolving real filesystem path from Document/Content Uri
        val resolvedPath = resolveDirectPath(context, uri)
        if (!resolvedPath.isNullOrBlank()) {
            return resolvedPath
        }

        // 3. Fallback: if resolution fails, guess Download folder path using display filename
        val fileName = getFileName(context, uri)
        val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        return File(downloadDir, fileName).absolutePath
    }

    private fun resolveDirectPath(context: Context, uri: Uri): String? {
        try {
            // Document Uri
            if (DocumentsContract.isDocumentUri(context, uri)) {
                
                // ExternalStorageProvider
                if (isExternalStorageDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).filter { it.isNotEmpty() }
                    if (split.isNotEmpty()) {
                        val type = split[0]
                        val subPath = if (split.size > 1) split[1] else ""

                        if ("primary".equals(type, ignoreCase = true)) {
                            val primaryDir = Environment.getExternalStorageDirectory()
                            val fullFile = File(primaryDir, subPath)
                            return fullFile.absolutePath
                        } else {
                            // Secondary SD Card or Custom Volumes
                            val storageDirs = context.getExternalFilesDirs(null)
                            for (dir in storageDirs) {
                                if (dir != null) {
                                    val path = dir.absolutePath
                                    if (path.contains(type)) {
                                        val root = path.substring(0, path.indexOf(type) + type.length)
                                        return File("$root/$subPath").absolutePath
                                    }
                                }
                            }
                            return File("/storage/$type/$subPath").absolutePath
                        }
                    }
                }
                // DownloadsProvider
                else if (isDownloadsDocument(uri)) {
                    val id = DocumentsContract.getDocumentId(uri)
                    if (id.startsWith("raw:")) {
                        val rawPath = id.replaceFirst("raw:".toRegex(), "")
                        return rawPath
                    }
                    if (id.contains("/storage/")) {
                        return id.substring(id.indexOf("/storage/"))
                    }
                    try {
                        val contentUri = ContentUris.withAppendedId(
                            Uri.parse("content://downloads/public_downloads"),
                            id.toLongOrNull() ?: return getDataColumn(context, uri, null, null)
                        )
                        val path = getDataColumn(context, contentUri, null, null)
                        if (!path.isNullOrEmpty()) return path
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    val fileName = getFileName(context, uri)
                    val downloadDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    return File(downloadDir, fileName).absolutePath
                }
                // MediaProvider
                else if (isMediaDocument(uri)) {
                    val docId = DocumentsContract.getDocumentId(uri)
                    val split = docId.split(":".toRegex()).filter { it.isNotEmpty() }
                    if (split.size >= 2) {
                        val type = split[0]
                        val mediaId = split[1]

                        val contentUri: Uri = when (type.lowercase()) {
                            "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                            "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                            else -> MediaStore.Files.getContentUri("external")
                        }

                        val selection = "_id=?"
                        val selectionArgs = arrayOf(mediaId)
                        val mediaPath = getDataColumn(context, contentUri, selection, selectionArgs)
                        if (!mediaPath.isNullOrEmpty()) {
                            return mediaPath
                        }
                    }
                }
            }

            // General Content Query
            val dataPath = getDataColumn(context, uri, null, null)
            if (!dataPath.isNullOrEmpty()) {
                return dataPath
            }

            // Scan decoded string for direct /storage/ paths
            val decodedString = try { URLDecoder.decode(uri.toString(), "UTF-8") } catch (e: Exception) { uri.toString() }
            if (decodedString.contains("/storage/emulated/0/")) {
                val index = decodedString.indexOf("/storage/emulated/0/")
                return decodedString.substring(index).split("?")[0].split("&")[0]
            }
            if (decodedString.contains("/storage/")) {
                val index = decodedString.indexOf("/storage/")
                return decodedString.substring(index).split("?")[0].split("&")[0]
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    private fun getDataColumn(
        context: Context,
        uri: Uri?,
        selection: String?,
        selectionArgs: Array<String>?
    ): String? {
        if (uri == null) return null
        val column = MediaStore.MediaColumns.DATA
        val projection = arrayOf(column)
        try {
            context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val columnIndex = cursor.getColumnIndex(column)
                    if (columnIndex != -1) {
                        return cursor.getString(columnIndex)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    /**
     * Gets display filename from Uri via ContentResolver.
     */
    fun getFileName(context: Context, uri: Uri): String {
        var name: String? = null
        if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
            try {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index != -1) {
                            name = cursor.getString(index)
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        if (name.isNullOrBlank()) {
            var raw = uri.lastPathSegment ?: "file_${System.currentTimeMillis()}"
            if (raw.contains(":")) {
                raw = raw.substringAfterLast(":")
            }
            if (raw.contains("/")) {
                raw = raw.substringAfterLast("/")
            }
            name = raw
        }
        return name ?: "selected_file"
    }

    private fun isExternalStorageDocument(uri: Uri): Boolean {
        return "com.android.externalstorage.documents" == uri.authority
    }

    private fun isDownloadsDocument(uri: Uri): Boolean {
        return "com.android.providers.downloads.documents" == uri.authority
    }

    private fun isMediaDocument(uri: Uri): Boolean {
        return "com.android.providers.media.documents" == uri.authority
    }
}

package com.example

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material.icons.filled.FolderOpen
import com.example.util.FilePathResolver
import com.example.data.FilePreviewInfo
import com.example.data.FileSwapManager
import com.example.service.FloatingService
import com.example.ui.theme.MyApplicationTheme
import com.example.util.PermissionUtils
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var fileSwapManager: FileSwapManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fileSwapManager = FileSwapManager(applicationContext)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                FileSwapperScreen(fileSwapManager = fileSwapManager)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh permissions state when returning from system settings
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileSwapperScreen(fileSwapManager: FileSwapManager) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val isServiceRunning by FloatingService.isServiceRunning.collectAsState()

    var hasOverlayPermission by remember { mutableStateOf(PermissionUtils.hasOverlayPermission(context)) }
    var hasFilePermission by remember { mutableStateOf(PermissionUtils.hasAllFilesAccess(context)) }
    var hasNotificationPermission by remember { mutableStateOf(PermissionUtils.hasNotificationPermission(context)) }

    var fileAPath by remember { mutableStateOf(fileSwapManager.getFileAPath()) }
    var fileBPath by remember { mutableStateOf(fileSwapManager.getFileBPath()) }

    var infoA by remember { mutableStateOf<FilePreviewInfo?>(null) }
    var infoB by remember { mutableStateOf<FilePreviewInfo?>(null) }

    fun refreshState() {
        hasOverlayPermission = PermissionUtils.hasOverlayPermission(context)
        hasFilePermission = PermissionUtils.hasAllFilesAccess(context)
        hasNotificationPermission = PermissionUtils.hasNotificationPermission(context)
        coroutineScope.launch {
            infoA = fileSwapManager.getFileInfo(fileAPath, fileSwapManager.getUriAString())
            infoB = fileSwapManager.getFileInfo(fileBPath, fileSwapManager.getUriBString())
        }
    }

    // Launcher for selecting File A using system File Picker app
    val launcherFileA = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val takeFlags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            val resolvedPath = FilePathResolver.getPath(context, uri) ?: uri.path ?: ""
            if (resolvedPath.isNotBlank()) {
                fileAPath = resolvedPath
                fileSwapManager.setPaths(
                    pathA = fileAPath,
                    pathB = fileBPath,
                    uriA = uri.toString(),
                    uriB = fileSwapManager.getUriBString()
                )
                refreshState()
                Toast.makeText(context, "تم تحديد الملف (أ) بنجاح!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Launcher for selecting File B using system File Picker app
    val launcherFileB = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val takeFlags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            val resolvedPath = FilePathResolver.getPath(context, uri) ?: uri.path ?: ""
            if (resolvedPath.isNotBlank()) {
                fileBPath = resolvedPath
                fileSwapManager.setPaths(
                    pathA = fileAPath,
                    pathB = fileBPath,
                    uriA = fileSwapManager.getUriAString(),
                    uriB = uri.toString()
                )
                refreshState()
                Toast.makeText(context, "تم تحديد الملف (ب) بنجاح!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(fileAPath, fileBPath) {
        refreshState()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "مبدل الملفات",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { refreshState() }) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "تحديث الحالة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // SERVICE CONTROLLER CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("service_controller_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isServiceRunning)
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                    else
                        MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(if (isServiceRunning) Color(0xFF10B981) else Color(0xFFEF4444))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isServiceRunning) "الفقاعة العائمة نشطة" else "الفقاعة العائمة متوقفة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isServiceRunning) Color(0xFF10B981).copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = if (isServiceRunning) "قيد التشغيل" else "متوقف",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isServiceRunning) Color(0xFF047857) else Color.DarkGray
                            )
                        }
                    }

                    Text(
                        text = "تعمل خدمة الفقاعة العائمة كزر قابل للسحب والتحريك فوق جميع التطبيقات. انقر فوق الفقاعة في أي وقت لتبديل الملف أ <-> الملف ب فوراً.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (!isServiceRunning) {
                            Button(
                                onClick = {
                                    if (!hasOverlayPermission) {
                                        Toast.makeText(context, "يرجى منح إذن الظهور فوق التطبيقات أولاً!", Toast.LENGTH_SHORT).show()
                                        PermissionUtils.requestOverlayPermission(context)
                                    } else {
                                        FloatingService.startService(context)
                                        refreshState()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("start_service_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تشغيل خدمة الفقاعة", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = {
                                    FloatingService.stopService(context)
                                    refreshState()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("stop_service_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إيقاف الخدمة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // REQUIRED PERMISSIONS CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("permissions_card"),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "أذونات النظام المطلوبة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    // Overlay Permission Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (hasOverlayPermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (hasOverlayPermission) Color(0xFF10B981) else Color(0xFFF59E0B)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("الظهور فوق التطبيقات (Overlay)", fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (hasOverlayPermission) "ممنوح" else "مطلوب الإجراء",
                                    fontSize = 12.sp,
                                    color = if (hasOverlayPermission) Color(0xFF10B981) else Color(0xFFD97706)
                                )
                            }
                        }

                        if (!hasOverlayPermission) {
                            Button(
                                onClick = { PermissionUtils.requestOverlayPermission(context) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("request_overlay_permission")
                            ) {
                                Text("منح الإذن")
                            }
                        }
                    }

                    // All Files Permission Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (hasFilePermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (hasFilePermission) Color(0xFF10B981) else Color(0xFFF59E0B)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("الوصول الشامل للملفات (Storage)", fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (hasFilePermission) "ممنوح" else "مطلوب الإجراء (أندرويد 11+)",
                                    fontSize = 12.sp,
                                    color = if (hasFilePermission) Color(0xFF10B981) else Color(0xFFD97706)
                                )
                            }
                        }

                        if (!hasFilePermission) {
                            Button(
                                onClick = { PermissionUtils.requestAllFilesAccess(context) },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("request_file_permission")
                            ) {
                                Text("منح الوصول")
                            }
                        }
                    }

                    // Notification Permission Row (Android 13+)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(
                                    imageVector = if (hasNotificationPermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (hasNotificationPermission) Color(0xFF10B981) else Color(0xFFF59E0B)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("إشعارات النظام (Notifications)", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = if (hasNotificationPermission) "ممنوح" else "مطلوب الإجراء (أندرويد 13+)",
                                        fontSize = 12.sp,
                                        color = if (hasNotificationPermission) Color(0xFF10B981) else Color(0xFFD97706)
                                    )
                                }
                            }

                            if (!hasNotificationPermission) {
                                Button(
                                    onClick = { PermissionUtils.requestNotificationPermission(context) },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("request_notification_permission")
                                ) {
                                    Text("منح الإذن")
                                }
                            }
                        }
                    }
                }
            }

            // FILE SWAP CONFIGURATION CARD
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("file_paths_card"),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مسارات الملفات المستهدفة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = {
                            fileSwapManager.resetToDefaults()
                            fileAPath = fileSwapManager.getFileAPath()
                            fileBPath = fileSwapManager.getFileBPath()
                            refreshState()
                            Toast.makeText(context, "تمت إعادة تعيين المسارات الافتراضية!", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(imageVector = Icons.Default.Restore, contentDescription = "إعادة التعيين")
                        }
                    }

                    Text(
                        text = "يمكنك تحديد مسارات الملفات التي تريد تبديل أسمائها فوراً أو تعديلها في الكود من FileSwapConfig.kt:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = fileAPath,
                        onValueChange = {
                            fileAPath = it
                            fileSwapManager.setPaths(fileAPath, fileBPath)
                        },
                        label = { Text("مسار الملف (أ)") },
                        trailingIcon = {
                            IconButton(
                                onClick = { launcherFileA.launch(arrayOf("*/*")) },
                                modifier = Modifier.testTag("browse_file_a_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "اختر الملف أ من مدير الملفات",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("file_a_path_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = fileBPath,
                        onValueChange = {
                            fileBPath = it
                            fileSwapManager.setPaths(fileAPath, fileBPath)
                        },
                        label = { Text("مسار الملف (ب)") },
                        trailingIcon = {
                            IconButton(
                                onClick = { launcherFileB.launch(arrayOf("*/*")) },
                                modifier = Modifier.testTag("browse_file_b_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "اختر الملف ب من مدير الملفات",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("file_b_path_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            // DEMO FILE GENERATOR & LIVE PREVIEW BENCH
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("test_bench_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "منصة الاختبار والمعاينة المباشرة للملفات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    val res = fileSwapManager.createDemoFiles()
                                    Toast.makeText(context, res.message, Toast.LENGTH_LONG).show()
                                    refreshState()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("create_demo_files_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(imageVector = Icons.Default.FolderSpecial, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إنشاء ملفات تجريبية", fontWeight = FontWeight.SemiBold)
                        }

                        OutlinedButton(
                            onClick = {
                                coroutineScope.launch {
                                    val res = fileSwapManager.performSwap()
                                    val msg = if (res.success) "✅ ${res.message}" else "❌ ${res.message}"
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    com.example.util.NotificationHelper.showSwapCompletionNotification(
                                        context = context,
                                        success = res.success,
                                        message = res.message
                                    )
                                    refreshState()
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("swap_now_app_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تبديل الآن", fontWeight = FontWeight.Bold)
                        }
                    }

                    // FILE PREVIEWS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // File A Box
                        FileStatusBox(
                            title = "الملف أ",
                            info = infoA,
                            modifier = Modifier.weight(1f)
                        )

                        // File B Box
                        FileStatusBox(
                            title = "الملف ب",
                            info = infoB,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun FileStatusBox(title: String, info: FilePreviewInfo?, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (info?.exists == true) Color(0xFF10B981) else Color(0xFFEF4444))
                )
            }

            Text(
                text = info?.fileName ?: "ملف",
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )

            Text(
                text = info?.contentPreview ?: "جاري التحميل...",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                maxLines = 4,
                lineHeight = 15.sp
            )

            AnimatedVisibility(visible = info?.exists == true) {
                Text(
                    text = "التعديل: ${info?.lastModified ?: ""}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

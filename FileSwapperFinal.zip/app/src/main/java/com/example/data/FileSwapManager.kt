package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import com.example.config.FileSwapConfig
import com.example.util.FilePathResolver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

data class SwapResult(
    val success: Boolean,
    val message: String
)

data class FilePreviewInfo(
    val path: String,
    val exists: Boolean,
    val fileName: String,
    val contentPreview: String,
    val lastModified: String
)

class FileSwapManager(private val context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        FileSwapConfig.PREFS_NAME,
        Context.MODE_PRIVATE
    )

    fun getFileAPath(): String {
        return prefs.getString(FileSwapConfig.KEY_FILE_A, null) ?: getDefaultFileAPath()
    }

    fun getFileBPath(): String {
        return prefs.getString(FileSwapConfig.KEY_FILE_B, null) ?: getDefaultFileBPath()
    }

    fun getTempFilePath(): String {
        return prefs.getString(FileSwapConfig.KEY_TEMP_FILE, null) ?: getDefaultTempPath()
    }

    fun getUriAString(): String? = prefs.getString(FileSwapConfig.KEY_URI_A, null)
    fun getUriBString(): String? = prefs.getString(FileSwapConfig.KEY_URI_B, null)

    fun setPaths(pathA: String, pathB: String, tempPath: String? = null, uriA: String? = null, uriB: String? = null) {
        prefs.edit().apply {
            putString(FileSwapConfig.KEY_FILE_A, pathA)
            putString(FileSwapConfig.KEY_FILE_B, pathB)
            if (tempPath != null) {
                putString(FileSwapConfig.KEY_TEMP_FILE, tempPath)
            }
            if (uriA != null) {
                putString(FileSwapConfig.KEY_URI_A, uriA)
            }
            if (uriB != null) {
                putString(FileSwapConfig.KEY_URI_B, uriB)
            }
            apply()
        }
    }

    fun resetToDefaults() {
        prefs.edit().clear().apply()
    }

    private fun getDefaultFileAPath(): String {
        val docsDir = getDocumentsDirectory()
        return File(docsDir, "FileA.txt").absolutePath
    }

    private fun getDefaultFileBPath(): String {
        val docsDir = getDocumentsDirectory()
        return File(docsDir, "FileB.txt").absolutePath
    }

    private fun getDefaultTempPath(): String {
        val docsDir = getDocumentsDirectory()
        return File(docsDir, "FileSwap_temp.tmp").absolutePath
    }

    private fun getDocumentsDirectory(): File {
        val externalDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        if (externalDocs != null && (externalDocs.exists() || externalDocs.mkdirs())) {
            return externalDocs
        }
        val appDocs = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "FileSwapper")
        if (!appDocs.exists()) {
            appDocs.mkdirs()
        }
        return appDocs
    }

    /**
     * Swaps File A and File B safely.
     */
    suspend fun performSwap(): SwapResult = withContext(Dispatchers.IO) {
        val pathA = getFileAPath()
        val pathB = getFileBPath()
        val pathTemp = getTempFilePath()
        val uriAStr = getUriAString()
        val uriBStr = getUriBString()

        val fileA = File(pathA)
        val fileB = File(pathB)
        val tempFile = File(pathTemp)

        var swapped = false
        var lastErrorMessage = ""

        // Clean up temp file if it previously existed
        if (tempFile.exists()) {
            try { tempFile.delete() } catch (e: Exception) { e.printStackTrace() }
        }

        // Attempt 1: Direct Atomic Rename Swap on disk
        if (fileA.exists() && fileB.exists()) {
            if (fileA.renameTo(tempFile)) {
                if (fileB.renameTo(fileA)) {
                    if (tempFile.renameTo(fileB)) {
                        swapped = true
                    } else {
                        fileA.renameTo(fileB)
                        tempFile.renameTo(fileA)
                    }
                } else {
                    tempFile.renameTo(fileA)
                }
            }
        }

        // Attempt 2: Direct File Copy Byte Swap on disk
        if (!swapped) {
            try {
                if (fileA.exists() && fileB.exists()) {
                    tempFile.parentFile?.mkdirs()
                    fileA.copyTo(tempFile, overwrite = true)
                    fileB.copyTo(fileA, overwrite = true)
                    tempFile.copyTo(fileB, overwrite = true)
                    if (tempFile.exists()) {
                        tempFile.delete()
                    }
                    swapped = true
                } else {
                    if (!fileA.exists()) lastErrorMessage = "الملف (أ) غير موجود في ${fileA.absolutePath}"
                    if (!fileB.exists()) lastErrorMessage = "الملف (ب) غير موجود في ${fileB.absolutePath}"
                }
            } catch (e: Exception) {
                lastErrorMessage = e.localizedMessage ?: "خطأ أثناء نسخ المحتوى بين الملفين"
            }
        }

        // Attempt 3: SAF Content Stream Swap (if URIs exist)
        if (!swapped && !uriAStr.isNullOrBlank() && !uriBStr.isNullOrBlank()) {
            try {
                val uriA = android.net.Uri.parse(uriAStr)
                val uriB = android.net.Uri.parse(uriBStr)
                val cacheTemp = File(context.cacheDir, "swap_temp.tmp")

                context.contentResolver.openInputStream(uriA)?.use { input ->
                    FileOutputStream(cacheTemp).use { output -> input.copyTo(output) }
                }
                context.contentResolver.openInputStream(uriB)?.use { input ->
                    context.contentResolver.openOutputStream(uriA, "rwt")?.use { output -> input.copyTo(output) }
                }
                FileInputStream(cacheTemp).use { input ->
                    context.contentResolver.openOutputStream(uriB, "rwt")?.use { output -> input.copyTo(output) }
                }
                if (cacheTemp.exists()) cacheTemp.delete()
                swapped = true
            } catch (e: Exception) {
                lastErrorMessage = e.localizedMessage ?: "فشل التبديل باستخدام بروتوكول ContentResolver"
            }
        }

        if (swapped) {
            val nameA = if (fileA.name.isNotBlank()) fileA.name else "الملف (أ)"
            val nameB = if (fileB.name.isNotBlank()) fileB.name else "الملف (ب)"
            return@withContext SwapResult(
                success = true,
                message = "تم التبديل بنجاح! ($nameA <-> $nameB)"
            )
        } else {
            val detail = if (lastErrorMessage.isNotBlank()) " ($lastErrorMessage)" else ""
            return@withContext SwapResult(
                success = false,
                message = "فشل التبديل! تأكد من وجود الملفات ومنح إذن 'وصول لجميع الملفات'.$detail"
            )
        }
    }

    /**
     * Creates sample demo files (File A and File B) for quick testing.
     */
    suspend fun createDemoFiles(): SwapResult = withContext(Dispatchers.IO) {
        val pathA = getFileAPath()
        val pathB = getFileBPath()

        val fileA = File(pathA)
        val fileB = File(pathB)

        try {
            fileA.parentFile?.mkdirs()
            fileB.parentFile?.mkdirs()

            fileA.writeText("هذا هو محتوى الملف (أ) الأصلي.\nتاريخ الإنشاء: ${System.currentTimeMillis()}")
            fileB.writeText("هذا هو محتوى الملف (ب) الأصلي.\nتاريخ الإنشاء: ${System.currentTimeMillis()}")

            return@withContext SwapResult(
                success = true,
                message = "تم إنشاء الملفات التجريبية بنجاح:\n(أ) ${fileA.absolutePath}\n(ب) ${fileB.absolutePath}"
            )
        } catch (e: Exception) {
            return@withContext SwapResult(
                success = false,
                message = "تعذر إنشاء الملفات التجريبية: ${e.localizedMessage}"
            )
        }
    }

    suspend fun getFileInfo(path: String, uriString: String? = null): FilePreviewInfo = withContext(Dispatchers.IO) {
        if (path.isBlank()) {
            return@withContext FilePreviewInfo(
                path = "",
                exists = false,
                fileName = "غير محدد",
                contentPreview = "[لم يتم تحديد المسار]",
                lastModified = "غير متوفر"
            )
        }

        val file = File(path)
        val existsOnDisk = try { file.exists() } catch (e: Exception) { false }

        if (existsOnDisk) {
            val content = try {
                val bytes = file.readBytes()
                val isBinary = bytes.take(60).any { it in 0..8 || it in 14..31 }
                if (isBinary) {
                    "📦 ملف ثنائي/وسائط (${formatFileSize(file.length())})"
                } else {
                    val text = String(bytes.take(200).toByteArray(), java.nio.charset.StandardCharsets.UTF_8).trim()
                    if (text.length > 120) text.take(120) + "..." else text.ifBlank { "[ملف فارغ]" }
                }
            } catch (e: Exception) {
                "[حجم الملف: ${formatFileSize(file.length())}]"
            }

            val lastMod = java.text.SimpleDateFormat("HH:mm:ss - MMM dd", java.util.Locale.getDefault())
                .format(java.util.Date(file.lastModified()))

            return@withContext FilePreviewInfo(
                path = file.absolutePath,
                exists = true,
                fileName = file.name,
                contentPreview = content,
                lastModified = lastMod
            )
        }

        // Check via Uri if provided
        if (!uriString.isNullOrBlank()) {
            try {
                val uri = android.net.Uri.parse(uriString)
                val name = FilePathResolver.getFileName(context, uri)
                var previewText = "[جاهز للتبديل]"
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val buf = ByteArray(200)
                    val read = input.read(buf)
                    if (read > 0) {
                        val readBytes = buf.copyOf(read)
                        val isBinary = readBytes.any { it in 0..8 || it in 14..31 }
                        previewText = if (isBinary) "📦 ملف ثنائي/وسائط" else String(readBytes, java.nio.charset.StandardCharsets.UTF_8).take(100)
                    }
                }
                return@withContext FilePreviewInfo(
                    path = path,
                    exists = true,
                    fileName = name,
                    contentPreview = previewText,
                    lastModified = "عبر إذن SAF"
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return@withContext FilePreviewInfo(
            path = path,
            exists = false,
            fileName = file.name.ifBlank { "غير محدد" },
            contentPreview = "[الملف غير موجود في المسار المحدّد]",
            lastModified = "غير متوفر"
        )
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val exp = (Math.log(bytes.toDouble()) / Math.log(1024.0)).toInt()
        val pre = "KMGTPE"[exp - 1]
        return String.format(java.util.Locale.US, "%.1f %sB", bytes / Math.pow(1024.0, exp.toDouble()), pre)
    }
}
